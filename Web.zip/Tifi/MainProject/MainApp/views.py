from django.shortcuts import render
from django.http import HttpResponse
# Create your views here.
import sqlite3
def Index(request):
    return render(request,'index.html')

#def register(request):

#    db = sqlite3.connect()
#    return render(request,'MainApp/register.html')

def login(request):
    return render(request,'login.html')
def register(request):
     return render(request,'register.html')

def Reg_Done(request):
    name = request.POST.get('name')
    mail  = request.POST.get('mail')
    phone = request.POST.get('phone')
    psw = request.POST.get('psw')
    rpsw =request.POST.get('rpsw')
    all = [name,mail,phone,psw,rpsw]

    return render(request,'Reg_Done.html',{'all':all})


""" db = sqlite3.connect('Registration')
    rs = db.cursor()

    rs.execute('''create table Register(name varchar(50), email varchar(100), phone varchar(10), password varchar(10))''')
    db.commit()


    rs.execute(''' insert into  Register values('Ali','@gmail.com', '03004020220',Logan1234#')''')
    db.commit()

    data = []

    rs.execute('select * from Register')
    for i in rs:
        data.append(i)
        print(i)"""